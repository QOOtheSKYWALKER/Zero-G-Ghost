// ============================================================
//  ZERO-G LAYER — Content Script  (runs in every page/frame)
//
//  Role: inject page_script.js into the PAGE JS context via
//  <script src="chrome-extension://..."> so it can wrap
//  window.fetch and window.XMLHttpRequest without any inline
//  script CSP violation.
//
//  All Wasm modules (COUNTER_WASM, SCROLL_ALIGNER_WASM) live
//  inside page_script.js — not here.
// ============================================================
'use strict';

// ── INJECT page_script.js ────────────────────────────────────────────────────
// <script src="..."> avoids unsafe-inline entirely.
// page_script.js is listed in web_accessible_resources so any page can load it.
function injectPageScript() {
  if (document.querySelector('script[data-zerog]')) return;
  const el = document.createElement('script');
  el.src           = chrome.runtime.getURL('page_script.js');
  el.dataset.zerog = '1';
  el.async         = false; // execute as early as possible
  (document.head || document.documentElement).prepend(el);
}

if (document.readyState === 'loading' || !document.head) {
  injectPageScript();
} else {
  injectPageScript();
}

// ── RECEIVE BLOCK EVENTS from page context ───────────────────────────────────
// page_script.js dispatches '__zerog_block__' CustomEvents when Wasm blocks
// a request. Content scripts can hear window events from the page context.
window.addEventListener('__zerog_block__', (e) => {
  const { count, url } = e.detail;
  if (count % 5 === 0 || count === 128) {
    chrome.runtime.sendMessage({
      type: 'WASM_BLOCK',
      count,
      url: url.slice(0, 200)
    }).catch(() => {});
  }
});
