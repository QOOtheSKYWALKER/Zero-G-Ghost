// ============================================================
//  ZERO-G LAYER — Background Service Worker (MV3)
//  Note: chrome.webRequest is NOT available in MV3 service workers.
//  Stats are received via messages from content_script.js instead.
// ============================================================
'use strict';

// Per-tab block stats (populated by messages from content_script.js)
const tabStats = new Map(); // tabId -> { count, blocked }

chrome.runtime.onInstalled.addListener(({ reason }) => {
  console.log('[Zero-G] Extension installed. reason:', reason);
  console.log('[Zero-G] declarativeNetRequest rules active (X-Frame-Options stripped).');
});

// Reset stats when tab navigates main frame
chrome.webNavigation.onCommitted.addListener(({ tabId, frameId }) => {
  if (frameId === 0) tabStats.delete(tabId);
});

// chrome.tabs.onRemoved is omitted — requires 'tabs' permission which is
// replaced by 'activeTab' for faster store review. tabStats entries for
// closed tabs will linger until the service worker restarts (browser reboot).
// chrome.tabs.onRemoved.addListener((tabId) => tabStats.delete(tabId));

// Messages from content_script.js
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  const tabId = sender.tab?.id;

  if (msg.type === 'WASM_BLOCK' && tabId != null) {
    if (!tabStats.has(tabId)) tabStats.set(tabId, { count: 0, blocked: 0 });
    const s = tabStats.get(tabId);
    s.blocked++;
    s.count = msg.count;
    console.log(`[Zero-G] Tab ${tabId}: Wasm blocked request #${msg.count} — ${msg.url}`);
  }

  if (msg.type === 'GET_STATS' && tabId != null) {
    sendResponse(tabStats.get(tabId) ?? { count: 0, blocked: 0 });
    return true;
  }
});
