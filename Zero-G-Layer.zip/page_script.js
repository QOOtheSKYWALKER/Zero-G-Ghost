// ============================================================
//  ZERO-G LAYER — Page Script  v2.1
//  Injected via <script src="chrome-extension://..."> — no unsafe-inline.
//
//  Bucket-based object limiter:
//  Each fetch/XHR URL is classified into a "bucket" by its hostname.
//  When a single bucket exceeds BUCKET_THRESHOLD requests, the nearest
//  DOM ancestor (article / li / [data-testid] / div with id or class) of
//  any media element whose src matches that host is hidden.
//  Gemini chat, Twitter API calls, YouTube player — all use different
//  hosts from ad/preview CDNs, so they are never affected.
// ============================================================
(function() {
  'use strict';
  if (window.__ZEROG_INTERCEPTOR__) return;
  window.__ZEROG_INTERCEPTOR__ = true;

  // ── Wasm bytes ─────────────────────────────────────────────────────────────
  const WASM_BYTES        = new Uint8Array([0, 97, 115, 109, 1, 0, 0, 0, 1, 8, 2, 96, 0, 1, 127, 96, 0, 0, 3, 6, 5, 0, 0, 0, 0, 1, 5, 3, 1, 0, 1, 7, 71, 6, 6, 109, 101, 109, 111, 114, 121, 2, 0, 11, 103, 101, 116, 95, 109, 101, 109, 95, 112, 116, 114, 0, 0, 9, 103, 101, 116, 95, 99, 111, 117, 110, 116, 0, 1, 12, 115, 104, 111, 117, 108, 100, 95, 98, 108, 111, 99, 107, 0, 2, 9, 105, 110, 99, 114, 101, 109, 101, 110, 116, 0, 3, 5, 114, 101, 115, 101, 116, 0, 4, 10, 140, 1, 5, 4, 0, 65, 0, 11, 7, 0, 65, 16, 40, 2, 0, 11, 11, 0, 65, 16, 40, 2, 0, 65, 128, 1, 79, 11, 75, 1, 3, 127, 65, 16, 40, 2, 0, 33, 0, 32, 0, 65, 128, 1, 79, 4, 64, 65, 1, 15, 11, 32, 0, 65, 5, 118, 65, 2, 116, 33, 1, 32, 0, 65, 31, 113, 33, 2, 32, 1, 32, 1, 40, 2, 0, 65, 1, 32, 2, 116, 114, 54, 2, 0, 65, 16, 32, 0, 65, 1, 106, 54, 2, 0, 32, 0, 65, 1, 106, 65, 128, 1, 79, 11, 37, 0, 65, 0, 65, 0, 54, 2, 0, 65, 4, 65, 0, 54, 2, 0, 65, 8, 65, 0, 54, 2, 0, 65, 12, 65, 0, 54, 2, 0, 65, 16, 65, 0, 54, 2, 0, 11]);
  const SCROLL_WASM_BYTES = new Uint8Array([0, 97, 115, 109, 1, 0, 0, 0, 1, 27, 5, 96, 0, 1, 127, 96, 1, 127, 0, 96, 2, 127, 127, 0, 96, 3, 127, 127, 127, 1, 127, 96, 2, 127, 127, 1, 127, 3, 6, 5, 0, 1, 2, 3, 4, 5, 3, 1, 0, 1, 7, 74, 6, 6, 109, 101, 109, 111, 114, 121, 2, 0, 14, 103, 101, 116, 95, 98, 105, 116, 109, 97, 112, 95, 112, 116, 114, 0, 0, 9, 115, 101, 116, 95, 99, 111, 117, 110, 116, 0, 1, 5, 115, 101, 116, 95, 121, 0, 2, 7, 99, 111, 109, 112, 117, 116, 101, 0, 3, 14, 99, 97, 108, 99, 95, 108, 111, 111, 107, 97, 104, 101, 97, 100, 0, 4, 10, 182, 2, 5, 5, 0, 65, 132, 8, 11, 9, 0, 65, 0, 32, 0, 54, 2, 0, 11, 15, 0, 65, 4, 32, 0, 65, 2, 116, 106, 32, 1, 54, 2, 0, 11, 187, 1, 1, 7, 127, 32, 0, 32, 1, 106, 32, 2, 106, 33, 8, 65, 0, 40, 2, 0, 33, 4, 65, 132, 8, 65, 0, 54, 2, 0, 65, 136, 8, 65, 0, 54, 2, 0, 65, 140, 8, 65, 0, 54, 2, 0, 65, 144, 8, 65, 0, 54, 2, 0, 65, 148, 8, 65, 0, 54, 2, 0, 65, 152, 8, 65, 0, 54, 2, 0, 65, 156, 8, 65, 0, 54, 2, 0, 65, 160, 8, 65, 0, 54, 2, 0, 65, 0, 33, 3, 2, 64, 3, 64, 32, 3, 32, 4, 79, 13, 1, 65, 4, 32, 3, 65, 2, 116, 106, 40, 2, 0, 33, 5, 32, 5, 32, 0, 32, 1, 106, 74, 32, 5, 32, 8, 76, 113, 4, 64, 65, 132, 8, 32, 3, 65, 5, 118, 65, 2, 116, 106, 33, 6, 32, 3, 65, 31, 113, 33, 7, 32, 6, 32, 6, 40, 2, 0, 65, 1, 32, 7, 116, 114, 54, 2, 0, 32, 9, 65, 1, 106, 33, 9, 11, 32, 3, 65, 1, 106, 33, 3, 12, 0, 11, 11, 32, 9, 11, 87, 1, 2, 127, 32, 1, 65, 1, 72, 4, 64, 65, 1, 33, 1, 11, 32, 1, 65, 228, 0, 74, 4, 64, 65, 228, 0, 33, 1, 11, 32, 0, 65, 232, 7, 108, 32, 1, 109, 33, 2, 65, 248, 0, 32, 2, 65, 180, 1, 108, 65, 232, 7, 109, 106, 33, 3, 32, 3, 65, 208, 0, 72, 4, 64, 65, 208, 0, 33, 3, 11, 32, 3, 65, 216, 4, 74, 4, 64, 65, 216, 4, 33, 3, 11, 32, 3, 11]);

  // ── Global Wasm counter (kept for scroll-aligner compatibility) ───────────
  let wasm     = null;
  let bitmap   = null;
  let fallback = 0;

  WebAssembly.instantiate(WASM_BYTES)
    .then(r => {
      wasm   = r.instance.exports;
      bitmap = new Uint32Array(wasm.memory.buffer, wasm.get_mem_ptr(), 4);
      console.log('[Zero-G Wasm] Bitmap counter ready.');
    })
    .catch(() => {});

  function isBlocking()  { return wasm ? !!wasm.should_block() : fallback >= 128; }
  function currentCount(){ return wasm ? wasm.get_count() : fallback; }

  // ── Bucket system ─────────────────────────────────────────────────────────
  // bucketKey(url) → hostname (e.g. "rr3---sn-abc.googlevideo.com")
  // Each host gets its own counter. When it hits BUCKET_THRESHOLD the host
  // is blocked and its associated DOM card is hidden.
  //
  // Why hostname and not full path?
  //   • YouTube video chunks come from dedicated per-stream hostnames
  //     (*.googlevideo.com, *.c.youtube.com) distinct from the API hosts
  //   • Ad pixels use ad-server domains (googleads, doubleclick, etc.)
  //   • This naturally separates "one video card" from "the whole site"
  const BUCKET_THRESHOLD = 128;
  const buckets = new Map(); // hostname → { count, blocked }
  const blockedHosts = new Set();

  function bucketKey(url) {
    try {
      return new URL(url, location.href).hostname;
    } catch(e) {
      return url.slice(0, 64); // fallback: truncated url as key
    }
  }

  // Tick a bucket. Returns true if this request should be blocked.
  function tickBucket(url) {
    const key = bucketKey(url);
    if (blockedHosts.has(key)) return true;

    let b = buckets.get(key);
    if (!b) { b = { count: 0 }; buckets.set(key, b); }
    b.count++;

    if (b.count >= BUCKET_THRESHOLD) {
      blockedHosts.add(key);
      console.log('[Zero-G] Bucket blocked:', key, '(' + b.count + ' requests)');
      scheduleBucketHide(key);
      return true;
    }
    return false;
  }

  // ── DOM hide: find the "card" ancestor of a media element ─────────────────
  // Walk up from a media element to find the nearest meaningful container.
  // Candidates (in priority order):
  //   article, [data-testid], li, [data-video-id], [data-ad-slot],
  //   div/section with an id or a non-trivial class
  function findCard(el) {
    let node = el.parentElement;
    const CARD_SELECTORS = [
      'article',
      '[data-testid]',
      '[data-video-id]',
      '[data-ad-unit-id]',
      '[data-ad-slot]',
      'li',
    ];
    while (node && node !== document.body) {
      for (let i = 0; i < CARD_SELECTORS.length; i++) {
        if (node.matches && node.matches(CARD_SELECTORS[i])) return node;
      }
      // div/section with a meaningful id or class (not just layout helpers)
      const tag = node.tagName;
      if (tag === 'DIV' || tag === 'SECTION') {
        if (node.id && node.id.length > 2) return node;
        const cls = node.className;
        if (typeof cls === 'string' && cls.trim().length > 4 &&
            !cls.includes('container') && !cls.includes('wrapper') &&
            !cls.includes('layout')) return node;
      }
      node = node.parentElement;
    }
    return el; // fallback: hide the element itself
  }

  // Hide a card (visibility:hidden + contain:strict keeps layout intact)
  function hideCard(el) {
    if (!el || el.__zg_card_hidden__) return;
    el.__zg_card_hidden__ = true;
    el.style.cssText += ';visibility:hidden!important;contain:strict!important;';
  }

  // scheduleBucketHide: when a host is blocked, find all media elements
  // whose src contains that host and hide their card ancestors.
  function scheduleBucketHide(host) {
    const run = () => {
      const all = document.querySelectorAll('img[src],video[src],source[src],iframe[src]');
      for (let i = 0; i < all.length; i++) {
        const el = all[i];
        try {
          const elHost = new URL(el.src || el.getAttribute('src'), location.href).hostname;
          if (elHost === host || elHost.endsWith('.' + host) || host.endsWith('.' + elHost)) {
            hideCard(findCard(el));
          }
        } catch(e) {}
      }
    };
    'requestIdleCallback' in window
      ? requestIdleCallback(run, { timeout: 1000 })
      : setTimeout(run, 0);
  }

  // ── Patch fetch ────────────────────────────────────────────────────────────
  // Only media/resource requests that exceed the per-host bucket are blocked.
  // API calls (JSON, text) are passed through even from blocked hosts because
  // they don't carry a resource type that would match the bucket logic.
  // We detect "media request" heuristically: no Accept header with text/html,
  // or URL contains known video/image path patterns.
  const _fetch = window.fetch.bind(window);

  // Returns true if this fetch is likely a media/ad chunk (not an API call).
  // isMediaFetch: returns true ONLY for binary media chunk requests.
  // Tracking pixels, conversion beacons, analytics, API calls → always false.
  // Rule order: explicit ALLOW-list first, then BLOCK-list.
  function isMediaFetch(input, init) {
    const url = (typeof input === 'string') ? input
              : (input instanceof Request)  ? input.url : String(input);

    // ── ALLOW-list: never block these, regardless of bucket state ──
    // Conversion pixels, analytics beacons, ad measurement endpoints,
    // any path containing 'conversion', 'pagead', 'collect', 'analytics',
    // 'beacon', 'pixel', 'event', 'gtm', 'gtag', 'log', 'report'
    if (/conversion|pagead|analytics|collect|beacon|pixel|\/event|gtm|gtag|\/log\b|\/report\b|adservice|measurement/i.test(url)) {
      return false;
    }

    // Accept header signals: JSON / HTML / plain-text → API call, not media
    const accept = (init && init.headers)
      ? (typeof init.headers.get === 'function'
          ? (init.headers.get('accept') || '')
          : (init.headers['Accept'] || init.headers['accept'] || ''))
      : (input instanceof Request ? (input.headers.get('accept') || '') : '');
    if (accept.includes('application/json') ||
        accept.includes('text/html')        ||
        accept.includes('text/plain'))       return false;

    // ── BLOCK-list: binary media chunk URLs only ──
    if (/\.(ts|m4s|m4v|mp4|webm|mp3|aac|jpg|jpeg|png|gif|webp|avif)(\?|$)/i.test(url)) return true;
    if (/videoplayback|chunked|fragment|segment|manifest|\.m3u8|googlevideo|cdn\.ampproject/i.test(url)) return true;

    return false;
  }

  window.fetch = function(input, init) {
    // Only intercept confirmed media fetches
    if (!isMediaFetch(input, init)) return _fetch(input, init);
    const url = (typeof input === 'string') ? input
              : (input instanceof Request)  ? input.url : String(input);
    if (tickBucket(url)) {
      return Promise.resolve(new Response('', { status: 200 }));
    }
    return _fetch(input, init);
  };

  // ── Patch XHR ─────────────────────────────────────────────────────────────
  const _open = XMLHttpRequest.prototype.open;
  const _send = XMLHttpRequest.prototype.send;

  XMLHttpRequest.prototype.open = function(method, url, ...rest) {
    this._zg_url = String(url);
    return _open.apply(this, [method, url, ...rest]);
  };

  XMLHttpRequest.prototype.send = function(...args) {
    const url = this._zg_url || '';
    // Same guard: only intercept confirmed media XHR
    if (isMediaFetch(url, null) && tickBucket(url)) {
      const self = this;
      setTimeout(() => {
        try {
          Object.defineProperty(self, 'readyState',   { configurable:true, get:()=>4 });
          Object.defineProperty(self, 'status',       { configurable:true, get:()=>200 });
          Object.defineProperty(self, 'responseText', { configurable:true, get:()=>'' });
          Object.defineProperty(self, 'response',     { configurable:true, get:()=>'' });
          self.dispatchEvent(new ProgressEvent('load'));
          self.dispatchEvent(new ProgressEvent('loadend'));
        } catch(e) {}
      }, 0);
      return;
    }
    return _send.apply(this, args);
  };

  // ── MutationObserver: watch new media elements ────────────────────────────
  // When a new media element with a src from a blocked host arrives,
  // hide its card immediately.
  const mo = new MutationObserver(muts => {
    if (blockedHosts.size === 0) return;
    for (const m of muts) {
      for (const node of m.addedNodes) {
        if (node.nodeType !== 1) continue;
        const src = node.src || node.getAttribute('src') || '';
        if (!src) continue;
        try {
          const host = new URL(src, location.href).hostname;
          if (blockedHosts.has(host)) hideCard(findCard(node));
        } catch(e) {}
      }
      // src attribute changed on existing element
      if (m.type === 'attributes' && m.target) {
        const el  = m.target;
        const src = el.src || el.getAttribute('src') || '';
        if (!src) continue;
        try {
          const host = new URL(src, location.href).hostname;
          if (blockedHosts.has(host)) hideCard(findCard(el));
        } catch(e) {}
      }
    }
  });
  mo.observe(document.documentElement, {
    childList: true, subtree: true,
    attributes: true, attributeFilter: ['src']
  });

  // Notify content-script world (for background stats)
  function notify(host) {
    window.dispatchEvent(new CustomEvent('__zerog_block__', {
      detail: { count: blockedHosts.size, url: host }
    }));
  }

  // ── Scroll Aligner Wasm ────────────────────────────────────────────────────
  // Design: "Lazy Sync" — IntersectionObserver drives element registration,
  // never querySelectorAll on full DOM. Debounced syncElements() limits
  // Wasm memory writes to once per 300ms idle window.
  //
  // Hot path (per scroll frame): zero DOM traversal, zero allocations.
  // Cold path (element sync): runs only on idle, viewport-near elements first.

  let scrollEx       = null;
  let scrollBitmap   = null;   // Uint32Array(8) zero-copy live view
  let trackedNodes   = [];     // fixed-length slot array, reused each sync
  let scrollDebounce = null;   // 200ms debounce timer
  let prevScrollY    = 0;
  let prevScrollTime = 0;
  let prevDy         = 0;      // last abs(dy) for velocity calc
  let prevDt         = 16;     // last dt (ms) for velocity calc
  let syncDebounce   = null;   // debounce timer for syncElements

  // IntersectionObserver: browser tells us which elements are near the viewport.
  // No querySelectorAll, no full-tree traversal.
  // threshold=0 fires when even 1px enters the margin zone.
  let elemIO = null;  // IntersectionObserver instance

  async function initScrollAligner() {
    if (scrollEx) return;
    try {
      const r = await WebAssembly.instantiate(SCROLL_WASM_BYTES);
      scrollEx     = r.instance.exports;
      scrollBitmap = new Uint32Array(scrollEx.memory.buffer, scrollEx.get_bitmap_ptr(), 8);
      console.log('[Zero-G Wasm] Scroll aligner ready. Memory:', scrollEx.memory.buffer.byteLength, 'bytes fixed.');

      // IntersectionObserver watches for elements approaching from below.
      // rootMargin '200px' means "fire when element is within 200px below viewport".
      // This replaces full-page querySelectorAll with a browser-native, off-main-thread scan.
      elemIO = new IntersectionObserver(_onIntersect, {
        rootMargin: '0px 0px 400px 0px',  // watch 400px below viewport
        threshold: 0
      });

      // Observe existing elements — but do it in small chunks to avoid
      // blocking the main thread on SNS pages with thousands of nodes.
      _observeChunked(document.querySelectorAll('img,video,audio,picture,iframe,embed'));

      window.addEventListener('scroll', onScroll, { passive: true });
    } catch(e) {
      console.warn('[Zero-G Wasm] Scroll aligner unavailable:', e.message);
    }
  }

  // Observe a NodeList in 32-element chunks yielded via setTimeout(0).
  // Each chunk is ~0.1ms — total cost is amortised across multiple frames.
  function _observeChunked(nodes) {
    const arr = Array.prototype.slice.call(nodes);
    let idx = 0;
    function step() {
      const end = Math.min(idx + 32, arr.length);
      for (; idx < end; idx++) {
        if (!arr[idx].__zg_hidden__) elemIO.observe(arr[idx]);
      }
      if (idx < arr.length) setTimeout(step, 0);
    }
    step();
  }

  // IntersectionObserver callback: called by the browser, off hot-path.
  // Only elements actually entering the extended viewport zone get registered.
  function _onIntersect(entries) {
    for (let i = 0; i < entries.length; i++) {
      const el = entries[i].target;
      if (el.__zg_hidden__) { elemIO.unobserve(el); continue; }
      // Queue a debounced Wasm sync — don't write immediately
      _scheduleSyncElements();
    }
  }

  // Debounced sync: waits 300ms of quiet before writing Y positions to Wasm.
  // On Twitter/X where new posts arrive every second, this prevents
  // constant Wasm memory rewrites from piling up.
  function _scheduleSyncElements() {
    if (syncDebounce) clearTimeout(syncDebounce);
    syncDebounce = setTimeout(_syncElements, 300);
  }

  // Write viewport-near elements into Wasm linear memory.
  // "Viewport-near" = getBoundingClientRect().top is within 2 viewportH.
  // This limits set_y() calls to ~32-64 elements even on huge SNS pages.
  function _syncElements() {
    syncDebounce = null;
    if (!scrollEx) return;

    const vh   = window.innerHeight;
    const sy   = window.scrollY;
    const near = [];

    // Walk only already-intersected nodes, not the full DOM
    for (let i = 0; i < trackedNodes.length; i++) {
      const el = trackedNodes[i];
      if (el.__zg_hidden__) continue;
      const absY = (el.getBoundingClientRect().top + sy) | 0;
      // Prioritise: only register elements within 2 viewports below current scroll
      if (absY > sy - vh && absY < sy + vh * 3) near.push({ el, absY });
    }

    // Also pick up any newly intersected nodes from IO (since last sync)
    elemIO.takeRecords().forEach(e => {
      const el = e.target;
      if (!el.__zg_hidden__ && !near.find(x => x.el === el)) {
        const absY = (el.getBoundingClientRect().top + sy) | 0;
        near.push({ el, absY });
      }
    });

    // Sort by Y so Wasm slot 0..n maps top-to-bottom (improves cache locality)
    near.sort((a, b) => a.absY - b.absY);
    const cap = Math.min(near.length, 256);

    trackedNodes = [];
    scrollEx.set_count(cap);
    for (let i = 0; i < cap; i++) {
      trackedNodes[i] = near[i].el;
      scrollEx.set_y(i, near[i].absY);
    }
  }

  // MutationObserver: when new nodes arrive (infinite scroll), observe them.
  // We only call elemIO.observe() — NOT querySelectorAll on the whole tree.
  const _moForIO = new MutationObserver(muts => {
    if (!elemIO) return;
    for (const m of muts) {
      for (const node of m.addedNodes) {
        if (node.nodeType !== 1) continue;
        // Observe the node itself if it's a media element
        const tag = node.tagName;
        if (tag==='IMG'||tag==='VIDEO'||tag==='AUDIO'||tag==='PICTURE') {
          if (!node.__zg_hidden__) elemIO.observe(node);
        }
        // Observe direct media children only (no deep querySelectorAll)
        const ch = node.children;
        for (let i = 0; ch && i < ch.length; i++) {
          const t = ch[i].tagName;
          if ((t==='IMG'||t==='VIDEO'||t==='AUDIO'||t==='PICTURE') && !ch[i].__zg_hidden__) {
            elemIO.observe(ch[i]);
          }
        }
      }
    }
  });
  _moForIO.observe(document.documentElement, { childList: true, subtree: true });

  // ── Tab visibility gate ───────────────────────────────────────────────────
  // When the tab is hidden: cancel any pending scroll work immediately.
  // When the tab becomes visible again: wait 400ms for the browser to finish
  // its own tab-restore work, then run processScroll() exactly once.
  // This prevents Zero-G from competing with Chrome's compositor during
  // the expensive tab-switch repaint that causes the "freeze" sensation.
  let tabVisible     = !document.hidden;
  let visibilityTimer = null;

  document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
      // Tab going away — cancel all pending scroll work
      tabVisible = false;
      if (scrollDebounce)   { clearTimeout(scrollDebounce);   scrollDebounce   = null; }
      if (visibilityTimer)  { clearTimeout(visibilityTimer);  visibilityTimer  = null; }
    } else {
      // Tab coming back — give browser 400ms to repaint before we touch the DOM
      tabVisible = false; // still gated until timer fires
      if (visibilityTimer) clearTimeout(visibilityTimer);
      visibilityTimer = setTimeout(() => {
        visibilityTimer = null;
        tabVisible = true;
        // One immediate sweep with last-known velocity (velocity reset to 0 = stationary)
        prevDy = 0;
        prevDt = 16;
        processScroll();
      }, 400);
    }
  });

  // ── Scroll debounce: 200ms ────────────────────────────────────────────────
  // onScroll fires on every scroll event but only records velocity data.
  // processScroll() runs at most once per 200ms, and only when tab is visible.
  function onScroll() {
    if (!scrollEx || !tabVisible) return;

    // Velocity tracking only — cheap, no DOM, no Wasm
    const now = performance.now();
    const sy  = window.scrollY | 0;
    const dy  = (sy - prevScrollY) | 0;
    const dt  = ((now - prevScrollTime) | 0) || 16;
    prevScrollY    = sy;
    prevScrollTime = now;
    prevDy = dy < 0 ? -dy : dy;
    prevDt = dt;

    // Debounce: cancel previous timer, fire after 200ms of quiet
    if (scrollDebounce) clearTimeout(scrollDebounce);
    scrollDebounce = setTimeout(processScroll, 200);
  }

  function processScroll() {
    scrollDebounce = null;
    if (!scrollEx || !tabVisible) return;

    // Wasm computes dynamic lookahead from last known velocity — O(1), no allocs
    const la = scrollEx.calc_lookahead(prevDy, prevDt);
    const sy = window.scrollY | 0;

    scrollEx.compute(sy, window.innerHeight | 0, la);

    // Read 256-bit result bitmap via Uint32Array live view — zero-copy, zero GC
    const len = trackedNodes.length;
    for (let i = 0; i < len; i++) {
      if ((scrollBitmap[i >> 5] >> (i & 31)) & 1) hideNode(trackedNodes[i]);
    }
  }


  console.log('[Zero-G Layer] Bucket interceptor active. BUCKET_THRESHOLD=' + BUCKET_THRESHOLD);

  window.__zerog_hideExistingMedia__ = function() { initScrollAligner(); };

  // Attach initial play guards — kept for safety, no hover-blocking logic
  (function() {
    const run = () => {
      const vids = document.querySelectorAll('video');
      for (let i = 0; i < vids.length; i++) {
        vids[i].addEventListener('play', function(e) {
          const host = (vids[i].src) ? (function(){ try{ return new URL(vids[i].src).hostname; }catch(e){return '';} })() : '';
          if (host && blockedHosts.has(host) && !e.isTrusted) {
            vids[i].pause();
          }
        }, true);
      }
    };
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', run);
    else run();
  })();
})();
