/* ============================================================
   ZERO-G LAYER — ENGINE
   ============================================================ */

// ── CACHE CLEAR — Physical Purge via chrome.browsingData ──────────────────
// Runs entirely in zero-g-layer.html (newtab page = extension page context).
// chrome.browsingData is NOT available in content scripts.

let paperInterval = null;

function openCacheDialog() {
  document.getElementById('cache-overlay').style.display = 'flex';
  document.getElementById('cache-status-text').textContent =
    'Clears cache, IndexedDB, and service workers. Cookies and local storage are preserved.';
  document.getElementById('cache-progress-bar').style.display = 'none';
  document.getElementById('cache-progress-fill').style.width = '0%';
  document.getElementById('cache-start-btn').disabled = false;
  document.getElementById('cache-cancel-btn').textContent = 'Cancel';
  document.getElementById('cache-cancel-btn').disabled = false;
  stopPapers();
}

function closeCacheDialog() {
  stopPapers();
  document.getElementById('cache-overlay').style.display = 'none';
}

// ── Flying papers animation ──────────────────────────────────────────────────
function spawnPaper() {
  const stage = document.getElementById('flying-stage');
  const p = document.createElement('div');
  p.className = 'paper';
  // Stagger vertical position slightly so papers don't stack perfectly
  const offsetY = (Math.random() - 0.5) * 18;
  p.style.marginTop = offsetY + 'px';
  stage.appendChild(p);
  // Trigger animation on next frame
  requestAnimationFrame(() => {
    requestAnimationFrame(() => { p.classList.add('fly'); });
  });
  // Remove after animation completes
  setTimeout(() => p.remove(), 1000);
}

function startPapers() {
  stopPapers();
  spawnPaper();
  paperInterval = setInterval(spawnPaper, 280);
}

function stopPapers() {
  if (paperInterval) { clearInterval(paperInterval); paperInterval = null; }
  // Clean up any remaining paper elements
  const stage = document.getElementById('flying-stage');
  stage.querySelectorAll('.paper').forEach(p => p.remove());
}

// ── The real purge ────────────────────────────────────────────────────────────
function startCacheClear() {
  const startBtn = document.getElementById('cache-start-btn');
  const cancelBtn = document.getElementById('cache-cancel-btn');
  const statusEl = document.getElementById('cache-status-text');
  const progBar  = document.getElementById('cache-progress-bar');
  const progFill = document.getElementById('cache-progress-fill');

  startBtn.disabled  = true;
  cancelBtn.disabled = true;
  progBar.style.display = 'block';
  statusEl.textContent = 'Clearing browser cache…';

  // Animate progress bar and papers simultaneously
  startPapers();
  let pct = 0;
  const progressTimer = setInterval(() => {
    pct = Math.min(pct + (Math.random() * 12), 90);
    progFill.style.width = pct + '%';
  }, 200);

  // chrome.browsingData: available because this is an extension page (newtab).
  // ⚠ appcache は MV3/現代Chromeで廃止済み → 含めるとエラー原因になるため除外。
  // ⚠ cookies / localStorage / passwords → ログイン情報保護のため意図的に除外。
  const dataTypes = {
    cache:          true,   // HTTPキャッシュ（本命・砂利パージ）
    cacheStorage:   true,   // Cache API (Service Worker キャッシュ)
    indexedDB:      true,   // IndexedDB
    fileSystems:    true,   // FileSystem API
    serviceWorkers: true,   // Service Worker 登録
    // webSQL removed — deprecated/unsupported in modern Chrome MV3
    formData:       true,   // フォーム入力履歴（軽量化効果あり）
    // cookies:     false   // ログイン情報を残す「規律」
    // localStorage:false   // 拡張機能設定を守るため除外
    // passwords:   false   // 絶対に触らない
  };

  chrome.browsingData.remove({ since: 0 }, dataTypes, () => {
    clearInterval(progressTimer);
    stopPapers();
    progFill.style.width = '100%';

    if (chrome.runtime.lastError) {
      statusEl.textContent = '⚠ Error: ' + chrome.runtime.lastError.message;
    } else {
      statusEl.textContent = '✅ Done! Cache, IndexedDB, Service Workers and form data cleared.';
    }
    cancelBtn.disabled = false;
    cancelBtn.textContent = 'Close';
    setStatus('Cache cleared — Zero-G Layer');
  });
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }


// ── OPEN IN CHROME ──────────────────────────────────────────────────────────
// Navigates current tab to the URL, hiding the Y2K browser.
function openInChrome() {
  const url = state.currentUrl;
  if (!url || url === 'about:blank') return;
  // window.location.href replaces the newtab page with the actual site
  window.location.href = url;
}

// ── STATE ──
const state = {
  history: [],
  historyIndex: -1,
  isLoading: false,
  currentUrl: '',
  wasm: null,
  wasmReady: false,
  loadTimeout: null,
};

// ── WASM MODULE ──
// URL validator: check_length(i32) -> i32  (1 = valid IE6-compat length, 0 = too long)
// Binary hand-encoded WAT:
// (module
//   (func $check_length (export "check_length") (param i32) (result i32)
//     local.get 0  i32.const 2083  i32.le_s)
//   (func $check_https  (export "check_https")  (param i32) (result i32)
//     ;; returns 1 if len >= 8 (likely has a scheme)
//     local.get 0  i32.const 8  i32.ge_s)
//   (func $url_score (export "url_score") (param i32) (result i32)
//     ;; score 0-3: 0=invalid, 1=ok, 2=good, 3=excellent
//     local.get 0  i32.const 0  i32.le_s  if  i32.const 0  return  end
//     local.get 0  i32.const 2083  i32.gt_s  if  i32.const 0  return  end
//     local.get 0  i32.const 100  i32.le_s  if  i32.const 3  return  end
//     local.get 0  i32.const 500  i32.le_s  if  i32.const 2  return  end
//     i32.const 1)
// )
const WASM_BYTES = new Uint8Array([
  // ── URL Validator Wasm — rebuilt clean (fixes CompileError @+15) ──
  // Type section: 1 type only → (i32)→i32  (byte[15]=0x7f, was 0x01)
  // Exports: check_length(len)→i32, check_https(len)→i32, url_score(len)→i32
  // Validated: Node.js all 9 cases ✅
  0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00, 0x01, 0x06, 0x01, 0x60, 0x01, 0x7f, 0x01, 0x7f,
  0x03, 0x04, 0x03, 0x00, 0x00, 0x00, 0x07, 0x2a, 0x03, 0x0c, 0x63, 0x68, 0x65, 0x63, 0x6b, 0x5f,
  0x6c, 0x65, 0x6e, 0x67, 0x74, 0x68, 0x00, 0x00, 0x0b, 0x63, 0x68, 0x65, 0x63, 0x6b, 0x5f, 0x68,
  0x74, 0x74, 0x70, 0x73, 0x00, 0x01, 0x09, 0x75, 0x72, 0x6c, 0x5f, 0x73, 0x63, 0x6f, 0x72, 0x65,
  0x00, 0x02, 0x0a, 0x46, 0x03, 0x08, 0x00, 0x20, 0x00, 0x41, 0xa3, 0x10, 0x4c, 0x0b, 0x07, 0x00,
  0x20, 0x00, 0x41, 0x08, 0x4e, 0x0b, 0x33, 0x00, 0x20, 0x00, 0x41, 0x00, 0x4c, 0x04, 0x40, 0x41,
  0x00, 0x0f, 0x0b, 0x20, 0x00, 0x41, 0xa3, 0x10, 0x4a, 0x04, 0x40, 0x41, 0x00, 0x0f, 0x0b, 0x20,
  0x00, 0x41, 0xe4, 0x00, 0x4c, 0x04, 0x40, 0x41, 0x03, 0x0f, 0x0b, 0x20, 0x00, 0x41, 0xf4, 0x03,
  0x4c, 0x04, 0x40, 0x41, 0x02, 0x0f, 0x0b, 0x41, 0x01, 0x0b,
])

async function initWasm() {
  try {
    const result = await WebAssembly.instantiate(WASM_BYTES);
    state.wasm = result.instance.exports;
    state.wasmReady = true;
    document.getElementById('wasm-indicator-dot').className = 'wasm-dot ok';
    document.getElementById('wasm-status-text').textContent =
      'WebAssembly module: ✓ ready — URL Validator v1 (check_length, check_https, url_score)';
    document.getElementById('wasm-badge').classList.add('active');
    console.log('[Zero-G WASM] Module loaded:', Object.keys(state.wasm).join(', '));
  } catch (e) {
    document.getElementById('wasm-indicator-dot').className = 'wasm-dot err';
    document.getElementById('wasm-status-text').textContent =
      'WebAssembly module: ✗ init failed — using JS fallback';
    console.warn('[Zero-G WASM] Init failed, using JS fallback:', e);
  }
}

// JS fallbacks if Wasm fails
function wasmCheckLength(len)  { return state.wasmReady ? state.wasm.check_length(len) : (len <= 2083 ? 1 : 0); }
function wasmCheckHttps(len)   { return state.wasmReady ? state.wasm.check_https(len)  : (len >= 8   ? 1 : 0); }
function wasmUrlScore(len)     {
  if (state.wasmReady) return state.wasm.url_score(len);
  if (len <= 0 || len > 2083) return 0;
  if (len <= 100) return 3;
  if (len <= 500) return 2;
  return 1;
}

// ── URL UTILITIES ──
function normalizeUrl(raw) {
  raw = raw.trim();
  if (!raw) return '';
  // If it looks like a search query, use Google
  if (!raw.includes('.') && !raw.startsWith('http')) {
    return 'https://www.google.com/search?q=' + encodeURIComponent(raw) + '&igu=1';
  }
  if (!/^https?:\/\//i.test(raw)) {
    return 'https://' + raw;
  }
  return raw;
}

function validateUrl(url) {
  const len = url.length;
  // Flash Wasm badge
  const badge = document.getElementById('wasm-badge');
  badge.classList.remove('active');
  void badge.offsetWidth;
  badge.classList.add('active');

  const valid  = wasmCheckLength(len);
  const hasScheme = wasmCheckHttps(len);
  const score  = wasmUrlScore(len);
  const labels = ['invalid', 'long', 'good', 'optimal'];
  const scoreColors = ['#CC2200','#888800','#006600','#004080'];

  // Show score in status bar
  const scorePanel = document.getElementById('wasm-score-panel');
  scorePanel.style.display = 'flex';
  scorePanel.style.color = scoreColors[score] || '#004080';
  scorePanel.textContent = `WASM: URL [${len} chars] ${labels[score] || 'unknown'} ${valid ? '✓' : '✗'}`;

  return { valid: !!valid, score, len };
}

// ── NAVIGATION ──
function navigate(url, pushHistory = true) {
  if (!url) return;
  url = normalizeUrl(url);
  if (!url) return;

  const { valid, score, len } = validateUrl(url);
  if (!valid) {
    setStatus(`⚠ URL too long (${len} chars / max 2083) — IE6 compat limit`);
    return;
  }

  state.currentUrl = url;
  document.getElementById('url-input').value = url;

  if (pushHistory) {
    state.history = state.history.slice(0, state.historyIndex + 1);
    state.history.push(url);
    state.historyIndex = state.history.length - 1;
  }

  updateNavButtons();
  startLoading(url);

  // Hide screens, show iframe
  document.getElementById('welcome-screen').style.display = 'none';
  document.getElementById('error-screen').style.display = 'none';
  const frame = document.getElementById('main-frame');
  frame.style.display = 'block';
  frame.src = url;

  // Detect X-Frame-Options block via timeout + check
  if (state.loadTimeout) clearTimeout(state.loadTimeout);
  state.loadTimeout = setTimeout(() => {
    if (state.isLoading) {
      // If still loading after 8s, assume blocked
      handleLoadBlock(url);
    }
  }, 8000);

  // Update padlock
  const padlock = document.getElementById('padlock-icon');
  padlock.textContent = url.startsWith('https://') ? '🔒' : '🔓';
}

function handleLoadBlock(url) {
  // The iframe may be blocked — show helpful error
  stopLoading();
  document.getElementById('main-frame').style.display = 'none';
  const errorScreen = document.getElementById('error-screen');
  document.getElementById('error-url-display').textContent = url;
  errorScreen.style.display = 'flex';
  setStatus('This page cannot be displayed in a frame.');
}

function goBack() {
  if (state.historyIndex > 0) {
    state.historyIndex--;
    navigate(state.history[state.historyIndex], false);
  }
}

function goForward() {
  if (state.historyIndex < state.history.length - 1) {
    state.historyIndex++;
    navigate(state.history[state.historyIndex], false);
  }
}

function refresh() {
  if (state.currentUrl && state.currentUrl !== '') {
    navigate(state.currentUrl, false);
  }
}

function goHome() {
  state.currentUrl = '';
  document.getElementById('url-input').value = '';
  document.getElementById('main-frame').style.display = 'none';
  document.getElementById('main-frame').src = 'about:blank';
  document.getElementById('error-screen').style.display = 'none';
  document.getElementById('welcome-screen').style.display = 'flex';
  stopLoading();
  setStatus('Done');
  document.getElementById('wasm-score-panel').style.display = 'none';
  document.getElementById('padlock-icon').textContent = '🔓';
}

function stopLoading() {
  if (state.loadTimeout) { clearTimeout(state.loadTimeout); state.loadTimeout = null; }
  state.isLoading = false;
  document.getElementById('main-frame').src = document.getElementById('main-frame').src; // cancel
  setLoadingUI(false);
}

function openInNewTab() {
  if (state.currentUrl) window.open(state.currentUrl, '_blank');
}

// ── INPUT HANDLING ──
function navigateFromInput() {
  const val = document.getElementById('url-input').value;
  navigate(val);
}

function navigateFromWelcome() {
  const val = document.getElementById('welcome-url-input').value;
  if (val) {
    document.getElementById('url-input').value = val;
    navigate(val);
  }
}

function quickNav(url) {
  document.getElementById('url-input').value = url;
  navigate(url);
  return false;
}

function showHistoryMenu(direction) { /* placeholder */ }

// ── LOADING STATE ──
function startLoading(url) {
  state.isLoading = true;
  setLoadingUI(true);
  setStatus('Connecting: ' + url);
}

function setLoadingUI(loading) {
  const throbber   = document.getElementById('throbber-box');
  const stop       = document.getElementById('btn-stop');
  const refresh    = document.getElementById('btn-refresh');
  const progressW  = document.getElementById('progress-wrap');
  const loadBar    = document.getElementById('loading-bar');
  const fill       = document.getElementById('progress-fill');
  const loadFill   = document.getElementById('loading-bar-fill');

  if (loading) {
    throbber.classList.add('loading');
    stop.disabled = false;
    refresh.disabled = true;
    progressW.style.display = 'block';
    loadBar.classList.add('indeterminate');
    // Animate progress
    let pct = 0;
    clearInterval(state._progressInterval);
    state._progressInterval = setInterval(() => {
      pct = Math.min(pct + (Math.random() * 8), 90);
      fill.style.width = pct + '%';
    }, 200);
  } else {
    throbber.classList.remove('loading');
    stop.disabled = true;
    refresh.disabled = false;
    loadBar.classList.remove('indeterminate');
    clearInterval(state._progressInterval);
    fill.style.width = '100%';
    setTimeout(() => {
      progressW.style.display = 'none';
      fill.style.width = '0%';
    }, 500);
  }
}

function setStatus(msg) {
  document.getElementById('status-text').textContent = msg;
}

function updateNavButtons() {
  const back    = document.getElementById('btn-back');
  const backDD  = document.getElementById('btn-back-dd');
  const fwd     = document.getElementById('btn-forward');
  const fwdDD   = document.getElementById('btn-fwd-dd');
  const canBack = state.historyIndex > 0;
  const canFwd  = state.historyIndex < state.history.length - 1;
  back.disabled    = !canBack;
  backDD.disabled  = !canBack;
  fwd.disabled     = !canFwd;
  fwdDD.disabled   = !canFwd;
}

// ── IFRAME EVENTS ──
const frame = document.getElementById('main-frame');

frame.addEventListener('load', () => {
  if (!state.isLoading && frame.src === 'about:blank') return;
  if (state.loadTimeout) { clearTimeout(state.loadTimeout); state.loadTimeout = null; }
  state.isLoading = false;
  setLoadingUI(false);

  const url = frame.src;
  if (url && url !== 'about:blank') {
    // Try to detect if content loaded or blocked
    let title = url;
    try {
      title = frame.contentDocument?.title || url;
    } catch(e) { /* cross-origin */ }

    setStatus('Done');
    document.title = (title !== url ? title + ' — ' : '') + 'Zero-G Layer';
    // Update title bar
    const titleEl = document.getElementById('title-text');
    titleEl.textContent = (title && title !== url ? title + ' — ' : '') + 'Zero-G Layer — Gateway Browser';
  }
});

frame.addEventListener('error', () => {
  if (state.loadTimeout) { clearTimeout(state.loadTimeout); state.loadTimeout = null; }
  handleLoadBlock(state.currentUrl);
});

// ── KEYBOARD SHORTCUTS ──
document.addEventListener('keydown', (e) => {
  const input = document.getElementById('url-input');
  const activeEl = document.activeElement;

  if (e.key === 'F5') { e.preventDefault(); refresh(); }
  if (e.key === 'Escape') { stopLoading(); }
  if (e.altKey && e.key === 'ArrowLeft') { e.preventDefault(); goBack(); }
  if (e.altKey && e.key === 'ArrowRight') { e.preventDefault(); goForward(); }
  if (e.altKey && e.key === 'd') { e.preventDefault(); input.select(); input.focus(); }

  if ((e.key === 'Enter') && activeEl === input) { navigateFromInput(); }
  if ((e.key === 'Enter') && activeEl === document.getElementById('welcome-url-input')) {
    navigateFromWelcome();
  }
});

// ── TITLE UPDATE on frame src change ──
const observer = new MutationObserver(() => {
  const url = frame.getAttribute('src');
  if (url && url !== 'about:blank' && url !== state.currentUrl) {
    state.currentUrl = url;
    document.getElementById('url-input').value = url;
    const padlock = document.getElementById('padlock-icon');
    padlock.textContent = url.startsWith('https://') ? '🔒' : '🔓';
    state.history = state.history.slice(0, state.historyIndex + 1);
    state.history.push(url);
    state.historyIndex = state.history.length - 1;
    updateNavButtons();
    validateUrl(url);
  }
});
observer.observe(frame, { attributes: true, attributeFilter: ['src'] });

// ── EVENT BINDINGS (no inline onclick — CSP compliant) ──────────────────────
document.addEventListener('DOMContentLoaded', () => {
  // Toolbar
  document.getElementById('btn-back')   .addEventListener('click', goBack);
  document.getElementById('btn-forward').addEventListener('click', goForward);
  document.getElementById('btn-stop')   .addEventListener('click', stopLoading);
  document.getElementById('btn-refresh').addEventListener('click', refresh);
  document.getElementById('btn-home')   .addEventListener('click', goHome);
  document.getElementById('btn-cache')        .addEventListener('click', openCacheDialog);
  document.getElementById('btn-open-chrome')  .addEventListener('click', openInChrome);

  // Address bar
  document.getElementById('btn-go').addEventListener('click', navigateFromInput);

  // Links bar (data-url)
  document.querySelectorAll('#links-bar .links-item[data-url]').forEach(a => {
    a.addEventListener('click', e => { e.preventDefault(); navigate(a.dataset.url); });
  });

  // Welcome screen
  document.getElementById('welcome-go-btn').addEventListener('click', navigateFromWelcome);
  document.querySelectorAll('.ql-btn[data-url]').forEach(a => {
    a.addEventListener('click', e => { e.preventDefault(); navigate(a.dataset.url); });
  });

  // Error screen
  document.getElementById('btn-open-new-tab') .addEventListener('click', openInNewTab);
  document.getElementById('btn-error-home')   .addEventListener('click', goHome);
  document.getElementById('btn-error-retry')  .addEventListener('click', refresh);

  // Cache dialog
  document.getElementById('cache-start-btn') .addEventListener('click', startCacheClear);
  document.getElementById('cache-cancel-btn').addEventListener('click', closeCacheDialog);
  document.getElementById('cache-close-x')  .addEventListener('click', closeCacheDialog);
});

// ── INIT ──
(async () => {
  await initWasm();
  updateNavButtons();
  setStatus('Ready — Zero-G Layer Gateway Browser v1.0β');

  setTimeout(() => {
    const wi = document.getElementById('welcome-url-input');
    if (wi) wi.focus();
  }, 300);
})();
